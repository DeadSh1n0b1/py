import datetime
 
print('Введите дату своего рождения.')
day = int(input('День: '))
month = int(input('Месяц: '))
year = int(input('Год: '))
TODAY = datetime.date.today()
print(f'Ваш возраст {TODAY.year - year - ((TODAY.month, TODAY.day) < (month, day))}')

print('Введите год,чтобы узнать високосный год или невисокосный.')
n = int(input())
2024
if n % 4 == 0 and n % 100 != 0 or n % 400 == 0:
    print("Високосный.")
else:
    print("Невисокосный.")

import datetime
date = datetime.datetime(2000, 8, 26)
print('Номер недели:')
print(date.weekday())
print('0= понедельник,', '1= вторник,', '2= среда,', '3= четверг,', '4= пятница,', '5= суббота,', '6= воскресенье.')

def print_digit_with_asterisks(digit):
    patterns = {
        '0': [" ** ", "* *", "* *", "* *", " ** "],
        '1': [" * ", " * ", " * ", " * ", " * "],
        '2': [" ** ", " * ", " ** ", " * ", " ** "],
        '3': [" ** ", " * ", " ** ", " * ", " ** "],
        '4': ["* *", "* *", " ** ", " * ", " * "],
        '5': [" ** ", "*  ", " ** ", " * ", " ** "],
        '6': [" ** ", "*  ", " ** ", "* *", " ** "],
        '7': [" ** ", " * ", " * ", " * ", " * "],
        '8': [" ** ", "* *", " ** ", "* *", " ** "],
        '9': [" ** ", "* *", " ** ", " * ", " ** "]
    }
    return patterns[digit]

def print_date_with_asterisks(date):
    day, month, year = date.split()
    year = year[-2:]
    numbers = day + ' ' + month + ' ' + year
    lines = [""] * 5
    for digit in numbers:
        if digit == ' ':
            for i in range(5):
                lines[i] += " "
        else:
            digit_lines = print_digit_with_asterisks(digit)
            for i in range(5):
                lines[i] += digit_lines[i] + " "
    print("\n".join(lines))

date_of_birth = input("Введите дату рождения в формате дд мм гггг: ")
print_date_with_asterisks(date_of_birth)
input() 

